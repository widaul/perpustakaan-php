function tekanTombol() {
    var element = document.body;
    element.classList.toggle("dark");}