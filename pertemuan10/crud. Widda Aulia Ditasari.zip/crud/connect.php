<?php

// menyambungkan php dan mysql
$db = mysqli_connect("localhost", "root", "", "perpustakaan") or die("gagal");

?>